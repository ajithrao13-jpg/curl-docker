-- =============================================================
-- 03_sample_data.sql
-- Representative sample data for every table in the test schema.
--
-- Purpose
-- -------
-- This script seeds the database with realistic baseline data so
-- that each unit test starts from a well-understood state.  It is
-- executed automatically by DatabaseSetup after the DDL scripts;
-- BaseTest.cleanAndReseed() re-runs it before every test method
-- so every test gets a clean, predictable dataset.
--
-- Tables populated (in FK-safe order)
-- ------------------------------------
--   dbo.STAGING            – 2 parent batches (IDs 1 and 2)
--   dbo.STAGING_FOLDERS    – 6 rows covering common scenarios
--   dbo.TARGET_FOLDERS     – 2 already-processed records
--   dbo.HASH_REGISTRY      – 2 hashes mirroring the TARGET rows
--   dbo.SYS_DELTA_LOG      – 1 prior-run audit entry
-- =============================================================

-- ---------------------------------------------------------------
-- 0. Clear existing rows (FK-safe order) before reseeding
-- ---------------------------------------------------------------
DELETE FROM dbo.STAGING_FOLDERS;
DELETE FROM dbo.TARGET_FOLDERS;
DELETE FROM dbo.HASH_REGISTRY;
DELETE FROM dbo.SYS_DELTA_LOG;
DELETE FROM dbo.STAGING;
DBCC CHECKIDENT ('dbo.STAGING', RESEED, 0);
GO

GO
